const COLORS = ["red", "blue", "green", "yellow", "orange", "purple", "pink", "black", "white", "gray"];

//
// Get a random color among the list of available colors
//
function randomColor() {
  const randomIndex = Math.floor(Math.random() * COLORS.length);
  return COLORS[randomIndex];
}

//
// Create a new card
//
function createCard() {
  // 1 - Random color for card
  const cardColor = randomColor();

  // 2 - Create card element
  const card = document.createElement("div");
  card.classList.add("card");
  card.style.backgroundColor = cardColor;

  // 3 - Set card text
  const cardText = document.createElement("p");
  cardText.textContent = `Color: ${cardColor}`;
  cardText.style.color = cardColor === "black" ? "white" : "black"; // Ensure text visibility

  // 4 - Set card footer
  const cardFooter = document.createElement("div");
  cardFooter.classList.add("card-footer");

  // 5 - Manage footer button (Remove button)
  const removeButton = document.createElement("button");
  removeButton.textContent = "Remove";
  removeButton.classList.add("btn-danger");
  removeButton.addEventListener("click", () => {
    card.remove();
  });

  // Append elements to card
  cardFooter.appendChild(removeButton);
  card.appendChild(cardText);
  card.appendChild(cardFooter);

  // 6 - Add card to container
  document.querySelector(".container").appendChild(card);
}

//----------------------------------------
