 

// Generate a random hexadecimal color
function getRandomHexColor() {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}


// When clicking on the RANDOM COLOR button:
// -	Generate a random color
// -	Set the body background color with this color
// -	Set the color label with the value of this color
 

// Get references to HTML elements
const resultColor = document.getElementById("result-color");
const button = document.querySelector("button");
const body = document.body;

// Add event listener to the button
button.addEventListener("click", function () {
    const randomColor = getRandomHexColor();
    body.style.backgroundColor = randomColor; // Set body background color
    resultColor.textContent = randomColor; // Update the label with the color value
});