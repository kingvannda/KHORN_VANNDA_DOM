// SECRET CODE  
const SECRET_CODE = 2359;

// DOM ELEMENTS  
const passwordView = document.getElementById("passwordView");
const lostView = document.getElementById("lostView");
const wonView = document.getElementById("wonView");

const checkButton = document.getElementById("checkButton");
checkButton.addEventListener("click", handleCheck);

const tryAgainButton = document.getElementById("tryAgainButton");
tryAgainButton.addEventListener("click", showGame);

const passwordInput = document.getElementById("passwordInput");
passwordInput.addEventListener("keypress", handleEnterPassword);

const instructionLabel = document.getElementById("instructionLabel");

let attempts = 3; // Number of attempts

// Hide a given element  
function hide(element) {
  element.style.display = "none";
}

// Show a given element  
function show(element) {
  element.style.display = "block";
}

// Show the game (reset)  
function showGame() {
  attempts = 3;
  instructionLabel.textContent = "Enter your code (You can try 3 times only !)";
  passwordInput.value = ""; // Clear input

  hide(lostView);
  hide(wonView);
  show(passwordView);
}

// Show win view  
function showWin() {
  hide(passwordView);
  show(wonView);
}

// Show lost view  
function showLost() {
  hide(passwordView);
  show(lostView);
}

// Check the entered password  
function handleCheck() {
  const enteredCode = parseInt(passwordInput.value, 10);

  if (enteredCode === SECRET_CODE) {
    showWin();
  } else {
    attempts--;
    if (attempts > 0) {
      instructionLabel.textContent = `Wrong code! ${attempts} attempts left.`;
    } else {
      showLost();
    }
  }

  passwordInput.value = ""; // Clear input after each attempt
}

// Handle pressing "Enter" key  
function handleEnterPassword(event) {
  if (event.key === "Enter") {
    handleCheck();
  }
}


 
function handleCheck() {
     // Manage your logic when the button is pressed
}

// MAIN   ---------------------------------------------------------

 