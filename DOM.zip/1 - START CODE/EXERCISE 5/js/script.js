// ----------------------------------------------------------------------------
// FUNCTIONS
// ----------------------------------------------------------------------------

function addItem() {
  // 1 - Get values from input fields
  let description = document.getElementById("description").value.trim();
  let priority = document.getElementById("priority").value;

  // Validate input
  if (description === "") {
    alert("Please enter a task description!");
    return;
  }

  // 2 - Create a new task object
  let newTask = {
    description: description,
    priority: priority,
  };

  // 3 - Add the new task object to the array
  tasks.push(newTask);

  // 4 - Display tasks in console
  console.log(tasks);

  // 5 - Clear input field after adding
  document.getElementById("description").value = "";
}

// ----------------------------------------------------------------------------
// MAIN
// ----------------------------------------------------------------------------

let tasks = [];

// Run addItem function when clicking the button
let addButton = document.getElementById("addButton");
addButton.addEventListener("click", addItem);
